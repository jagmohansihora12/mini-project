chrome.tabs.onUpdated.addListner((tabId,tab)=>{
    if(tab.url && tab.url.includes("en.wikipedia.org/wiki")){
        const queryParameters = tab.url.split("?")[1];
        const urlParameters = new URLSearchParams(queryParameters);
    
        chrome.tabs.sendMessage(tabId, {
          type: "NEW",
          videoId: urlParameters.get("v"),
        });
      }
    });